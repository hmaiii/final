this project is a simple game with scrache
a chike follow the eggs and tries doesnt tuch them then if the chick
is sucessfull you get score 
you just need enter tab until the chicken up
thanks cs50:)
